<?php  include("templates/header.php"); ?>
    <div id="Contenedor">
        <section>
            <article style=" width: 80%;margin: 10% auto;"> 
             <!--<h1 style="text-align: center; "><pre><br>
               Trabajo Grupal <br>
              Fase 3 <br>
              ALEXIS VILLAMIZAR GOMEZ  CC:88254888 <br>
              ELWER GONZALES ROBAYO CC: 1090364355 <br>
              JOSE MAURICIOSAAVEDRA CC: 88268989 <br>
              WILLIAM YESID OVALLE CANO CC:1063621270 <br>
              </pre></h1> >-->
            </article>
        </section>
        <aside>
            
        </aside>
    </div>

    <footer>
        
    </footer>
        
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>     
    

        </body>

</html>
